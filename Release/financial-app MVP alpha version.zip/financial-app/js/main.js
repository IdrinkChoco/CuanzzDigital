// js/main.js
import { renderDashboard } from './components/dashboardView.js';
import { setupTransactionForm } from './components/transactionForm.js';

// 1. DAFDARKAN switchTab KE WINDOW AGAR BISA DIBACA OLEH ONCLICK HTML
window.switchTab = function (tabName) {
  const dashboardTab = document.getElementById('tab-dashboard');
  const transactionTab = document.getElementById('tab-transaction');
  const btnDashboard = document.getElementById('btn-tab-dashboard');
  const btnTransaction = document.getElementById('btn-tab-transaction');

  if (!dashboardTab || !transactionTab) return;

  if (tabName === 'dashboard') {
    dashboardTab.classList.remove('hidden');
    transactionTab.classList.add('hidden');
    btnDashboard?.classList.add('tab-active');
    btnTransaction?.classList.remove('tab-active');
  } else {
    dashboardTab.classList.add('hidden');
    transactionTab.classList.remove('hidden');
    btnDashboard?.classList.remove('tab-active');
    btnTransaction?.classList.add('tab-active');
  }
};

// 2. INISIALISASI APLIKASI SAAT HTML SELESAI DIMUAT
document.addEventListener('DOMContentLoaded', () => {
  // Hitung rentang tanggal bulan ini sebagai default filter
  const today = new Date();
  const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
  const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0];

  // Render awal Dashboard
  renderDashboard(firstDay, lastDay);

  // Setup Form Transaksi & Auto-switch ke Dashboard setelah simpan
  setupTransactionForm(() => {
    window.switchTab('dashboard');
    renderDashboard(firstDay, lastDay);
  });

  // Listener untuk tombol Filter Tanggal
  const btnApplyFilter = document.querySelector('#tab-dashboard button');
  if (btnApplyFilter) {
    btnApplyFilter.addEventListener('click', () => {
      const dates = document.querySelectorAll('#tab-dashboard input[type="date"]');
      if (dates.length >= 2) {
        renderDashboard(dates[0].value, dates[1].value);
      }
    });
  }
});